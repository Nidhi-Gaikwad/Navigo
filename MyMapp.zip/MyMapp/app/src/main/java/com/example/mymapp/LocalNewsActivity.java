package com.example.mymapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

import java.util.ArrayList;
import java.util.List;

public class LocalNewsActivity extends AppCompatActivity {

    private EditText locationInput;
    private Button getNewsButton;
    private ListView newsListView;
    private List<String> newsList;
    private ArrayAdapter<String> adapter;
    private NewsApiService newsApiService;
    private static final String API_KEY = "dfea9b2a1b084d39b3e44e2cf4309705"; // Replace with your actual API key

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_local_news);

        locationInput = findViewById(R.id.location_input);
        getNewsButton = findViewById(R.id.btn_get_news);
        newsListView = findViewById(R.id.news_list_view);
        newsList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, newsList);
        newsListView.setAdapter(adapter);

        // Get latitude and longitude from intent
        double latitude = getIntent().getDoubleExtra("latitude", 0);
        double longitude = getIntent().getDoubleExtra("longitude", 0);

        Retrofit retrofit = RetrofitClient.getClient("https://newsapi.org/v2/");
        newsApiService = retrofit.create(NewsApiService.class);

        if (latitude != 0 && longitude != 0) {
            // Fetch news based on location if latitude and longitude are valid
            fetchLocalNews(latitude, longitude);
        } else {
            // Prompt user to enter location if no coordinates are provided
            getNewsButton.setOnClickListener(v -> {
                String location = locationInput.getText().toString().trim();
                if (!location.isEmpty()) {
                    fetchLocalNews(location); // Optional: Implement geocoding here
                } else {
                    Toast.makeText(LocalNewsActivity.this, "Please enter a location", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public void fetchLocalNews(double latitude, double longitude) {
        // Modify API call to accept latitude and longitude and fetch news
        newsApiService.getNewsByLocation(latitude, longitude, API_KEY).enqueue(new Callback<NewsResponse>() {
            @Override
            public void onResponse(Call<NewsResponse> call, Response<NewsResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<NewsResponse.Article> articles = response.body().getArticles();
                    if (articles != null && !articles.isEmpty()) {
                        newsList.clear();
                        for (NewsResponse.Article article : articles) {
                            String newsItem = article.getTitle() + "\n" + article.getDescription();
                            newsList.add(newsItem);
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        Log.d("LocalNewsActivity", "No articles found for this location");
                    }
                } else {
                    Log.e("LocalNewsActivity", "Error: " + response.code() + " - " + response.message());
                }
            }

            @Override
            public void onFailure(Call<NewsResponse> call, Throwable t) {
                Log.e("LocalNewsActivity", "Failed to fetch news: " + t.getMessage());
            }
        });
    }


    // Fetch local news
    private void fetchLocalNews(String location) {
        Log.d("LocalNewsActivity", "Fetching news for location: " + location);

        newsApiService.getNewsByLocation(location, API_KEY).enqueue(new Callback<NewsResponse>() {
            @Override
            public void onResponse(Call<NewsResponse> call, Response<NewsResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    Log.d("LocalNewsActivity", "News response: " + response.body().toString());

                    List<NewsResponse.Article> articles = response.body().getArticles();
                    if (articles != null && !articles.isEmpty()) {
                        newsList.clear();
                        for (NewsResponse.Article article : articles) {
                            String newsItem = article.getTitle() + "\n" + article.getDescription();
                            newsList.add(newsItem);
                        }
                        adapter.notifyDataSetChanged();
                    } else {
                        Log.d("LocalNewsActivity", "No articles found for location: " + location);
                    }
                } else {
                    Log.e("LocalNewsActivity", "Error: " + response.code() + " - " + response.message());
                }
            }

            @Override
            public void onFailure(Call<NewsResponse> call, Throwable t) {
                Log.e("LocalNewsActivity", "Failed to fetch news: " + t.getMessage());
            }
        });
    }
}
