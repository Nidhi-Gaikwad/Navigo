package com.example.mymapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.logging.HttpLoggingInterceptor;

public class ItineraryPlannerActivity extends AppCompatActivity {

    private EditText editTextLocation;
    private EditText editTextPreferences;
    private Button buttonGenerateItinerary;
    private TextView textViewItinerary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itinerary_planner);

        editTextLocation = findViewById(R.id.editTextLocation);
        editTextPreferences = findViewById(R.id.editTextPreferences);
        buttonGenerateItinerary = findViewById(R.id.buttonGenerateItinerary);
        textViewItinerary = findViewById(R.id.textViewItinerary);

        buttonGenerateItinerary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String location = editTextLocation.getText().toString();
                String preferences = editTextPreferences.getText().toString();
                generateItinerary(location, preferences);
            }
        });
    }

    private void generateItinerary(String location, String preferences) {
        // Logging for debugging
        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        // OkHttpClient to add authorization header
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(logging)
                .addInterceptor(chain -> {
                    Request original = chain.request();
                    Request.Builder builder = original.newBuilder()
                            .header("Authorization", "Bearer AIzaSyAXlYnmx9_8dxpBWRbfPA1kVngt0fI1UDk"); // Replace with your valid token
                    Request request = builder.build();
                    return chain.proceed(request);
                }).build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://generativelanguage.googleapis.com/v1beta/")  // Replace with the correct API base URL
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        GeminiApiService apiService = retrofit.create(GeminiApiService.class);

        String prompt = "Plan a 3-day itinerary for a trip to " + location + ". Preferences: " + preferences;
        GeminiRequest request = new GeminiRequest(
                Arrays.asList(new GeminiRequest.Message("user", prompt))
        );

        Call<GeminiResponse> call = apiService.getItinerary(request);

        call.enqueue(new Callback<GeminiResponse>() {
            @Override
            public void onResponse(Call<GeminiResponse> call, Response<GeminiResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    GeminiResponse geminiResponse = response.body();
                    textViewItinerary.setText(geminiResponse.getResponse());
                } else {
                    try {
                        String errorMessage = response.errorBody() != null ? response.errorBody().string() : "Unknown error";
                        Log.e("API_ERROR", "Error: " + errorMessage);
                        textViewItinerary.setText("Failed to generate itinerary. Error: " + errorMessage);
                    } catch (Exception e) {
                        Log.e("API_ERROR", "Exception: " + e.getMessage());
                        textViewItinerary.setText("Failed to generate itinerary and read error message.");
                    }
                }
            }

            @Override
            public void onFailure(Call<GeminiResponse> call, Throwable t) {
                Log.e("API_ERROR", "Request failed: " + t.getMessage());
                textViewItinerary.setText("Error: " + t.getMessage());
            }
        });
    }
}
