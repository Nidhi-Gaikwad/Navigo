package com.example.mymapp;

public class GeminiResponse {
    private String response;  // Adjust based on Gemini’s actual response format

    public String getResponse() {
        return response;
    }
}
