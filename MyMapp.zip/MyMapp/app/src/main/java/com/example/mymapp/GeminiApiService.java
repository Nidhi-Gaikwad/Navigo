package com.example.mymapp;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface GeminiApiService {

    @Headers({
            "Content-Type: application/json",
            "Authorization: Bearer AIzaSyAXlYnmx9_8dxpBWRbfPA1kVngt0fI1UDk"  // Replace with your actual Gemini API key
    })
    @GET("models/gemini-1.5-flash-latest:generateContent")
    Call<GeminiResponse> generateContent(
            @Query("key") String apiKey,
            @Body GeminiRequest body
    );

    @POST("chat/completions")
    Call<GeminiResponse> getItinerary(@Body GeminiRequest request);
}
