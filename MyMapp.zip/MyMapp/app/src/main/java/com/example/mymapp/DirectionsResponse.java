package com.example.mymapp;

public class DirectionsResponse {
    public String status;
    public Routes[] routes;

    public static class Routes {
        public Leg[] legs;
        public Object overview_polyline;

        public static class Leg {
            public Distance distance;
            public Duration duration;
            public Step[] steps;

            public static class Distance {
                public String text;
            }

            public static class Duration {
                public String text;
            }

            public static class Step {
                public String html_instructions;
                public Polyline polyline;

                public static class Polyline {
                    public String points;
                }
            }
        }
    }
}